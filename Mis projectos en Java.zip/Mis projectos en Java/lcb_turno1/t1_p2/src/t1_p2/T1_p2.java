//Desarollo de Java de un ticket de caja

package t1_p2;

/**
 *
 * @author PC3
 */
public class T1_p2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println( "Articulo,Precio,Caja,No.caja");
        System.out.println( "Peras=4,50€,No.Caja=3");
        System.out.println( "Manzanas,Precio=2,35€,Caja,No.caja=4");
        System.out.println( "Naranjas,Precio=4,70€,No.caja=5");
        
    }
    
}
